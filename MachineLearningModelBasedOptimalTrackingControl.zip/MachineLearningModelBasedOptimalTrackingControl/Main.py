import scipy.io
import itertools
import matplotlib.pyplot as plt
import numpy as np
import math
from torch.utils.data import DataLoader
import torch

from torch.optim.lr_scheduler import LambdaLR


from sympy import *

from modules import DynamicsModelRNN,Net,NetF, NetBF, Counter, Initialize_weight

import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn import preprocessing
import os

import copy

import debugpy
debugpy.debug_this_thread()


 

 

def systemGenerateData(modelF, x1_0, x2_0, Flag_train, t_final, FlagCLF0, modeldx):

    global kdVdt, ksumV, knonzero, allnum

    allnum = allnum+1

    CAs = 0.5734
    Ts = 395.3268

    Qa = 9.35
    Qb = 0.41
    Qc = 0.41
    Qd = 0.02
    Q = np.array([[Qa, Qb], [Qc, Qd]])
    R = np.array([[1/100, 0], [0, 1/500]])
 

    lambda0 = 5000
    alpha0 = 0.1

    CF = 100e-3
    CV = 0.1
    Ck0 = 72e+9
    CE = 8.314e+4
    CR = 8.314
    CT0 = 310
    CDh = -4.78e+4
    Ccp = 0.239
    Crho = 1000

    CA0s = 1
    Qs = 0

    ua_ = np.array([[0.0], [0.0]])
    ua = np.array([[0.0], [0.0]])
    dx = np.array([[0.0], [0.0]])

    t_step = 0.001
    t_final = t_final

    sumV = 0

    x1, x2 = x1_0, x2_0

    x1_list = list()  # evolution of state over time
    x2_list = list()  # evolution of state time
    u1_list = list()
    u2_list = list()
    hat_V_list = list()
    dVdt_list = list()

    t_list = list()
    save_data = []
    NNoutput_list10 = []
    NNoutput_list20 = []
    dVdX1_list = []
    dVdX2_list = []

    lastV = 0
    dVdt = 0

    for i in range(int(t_final / t_step)):

        f1 = (CF / CV) * (- x1) - Ck0 * np.exp(-CE / (CR * (x2 + Ts))) * \
            (x1 + CAs)+(CF / CV) * (CA0s-CAs)
        f2 = (CF / CV) * (-x2) + (-CDh / (Crho * Ccp)) * Ck0 * \
            np.exp(-CE / (CR * (x2 + Ts))) * (x1 + CAs) + CF*(CT0-Ts)/CV

        g1 = CF / CV
        g2 = 1 / (Crho * Ccp * CV)

        f0 = np.array([[f1], [f2]])
        g0 = np.array([[g1, 0], [0, g2]])

 
        f = np.array([[f1], [f2]])
        g = np.array([[g1, 0], [0, g2]])

        # -----------------------------------------------------------------
        # optimal sontag's controller
        # ---------------------------------------------------------------
        #-- barrier function---#

        BF_FD = (x1+0.22)*(x1+0.22)+(x2-4.6)*(x2-4.6)/10000

        if BF_FD < 0.0004:

            BF = 5000*(np.exp((0.001 * BF_FD * BF_FD)/(BF_FD-0.0004)
                              ) - np.exp(-2*0.001*10e-4))-1.685*0.01-(5000*(-np.exp(-2*0.001*10e-4))-1.685*0.01)

            A = alpha0*(x1+0.22)*(x1+0.22)+alpha0 * \
                (x2-4.6)*(x2-4.6)/10000-alpha0*0.0004

            dBFdX1 = lambda0 * (np.exp(-A)) * (-2*alpha0*(x1+0.22))
            dBFdX2 = lambda0 * (np.exp(-A)) * (-0.0002*alpha0*(x2-4.6))

            dBFdX = np.array([[dBFdX1], [dBFdX2]])
            # dBFdX = np.array([[0], [0]])
            # BF = 0
        else:
            BF = 5000*(-np.exp(-2*0.001*10e-4))-1.685*0.01 - \
                (5000*(-np.exp(-2*0.001*10e-4))-1.685*0.01)
            dBFdX = np.array([[0], [0]])
            BF = 0
        # ------------------------------------------
        # NN prediction
        # -------------------------------------------

        testdata = torch.tensor(np.array([[(x1)/1, (x2)/1]]))
        predict = net_predict(testdata, modelF)

        NNV = predict[0]
        dVdX = predict[1].view(-1, 1)
        hat_VV = NNV[0][0]

        QX = np.array([[x1, x2]]) @ Q @ np.array([[x1], [x2]])

        dx0 = f+g @ ua
        ua_ = -0.5 * (np.linalg.inv(np.transpose(g) @ R @ g)) @ (2 *
                                                                 np.transpose(g) @ R @ (dx0-g @ ua) + np.transpose(g) @ (np.array(dVdX)+dBFdX*0))

        ua[0] = ua_[0][0]
        ua[1] = ua_[1][0]

        u1b = 2  # 2.2  # 1  # 15
        u2b = 0.167  # 4.67  # 0.0167  # 25

        if (ua_[0][0] > u1b):
            ua_[0][0] = u1b
        elif (ua_[0][0] < -u1b):
            ua_[0][0] = -u1b

        if ua_[1][0] > u2b:
            ua_[1][0] = u2b
        elif ua_[1][0] < -u2b:
            ua_[1][0] = -u2b
        ua = ua_

        dx = f0+g0 @ ua

        dVdt = np.transpose(dVdX)@dx
        dVdt = dVdt[0][0]

        U = np.transpose(dx) @ R @ dx

        # ---------------------------------
        # NN training data
        # ---------------------------------

        save_data0 = np.array(
            [[(x1)/1, (x2)/1, dx[0][0], dx[1][0], U[0][0]]])
        save_data.append(save_data0)
        traindata = np.array(save_data)

        # ---------------------------------
        # check
        # ---------------------------------
        sumV = sumV+BF + \
            np.array([[x1, x2]]) @ Q @ np.array([[x1], [x2]]) + U*1

        if Flag_train == 1:
            if sumV > 500:  # 1e16:
                FlagCLF = 0
                ksumV = ksumV+1

        if Flag_train == 1:
            FlagCLF = 1
        else:
            if FlagCLF0 == 0:
                if dVdt <= 0:
                    FlagCLF = i
                else:
                    FlagCLF = i
                    print(f"i={i};dVdt > 0")
                    FlagCLF0 = 1

        # print(f"iteration {i}","----------------------")

        NNoutput = predict[2]
        NNoutput_list10.append(NNoutput[0][0])
        NNoutput_list1 = np.array(NNoutput_list10)
        NNoutput_list20.append(NNoutput[0][1])
        NNoutput_list2 = np.array(NNoutput_list20)

        if i % 100 == 0:
            print(f"---i= {i} ---")
            print(f'Predition: u=[{ua[0][0]:.4f},{ua[1][0]:.4f}]', f'hat_V={NNV[0][0]:.5f}', f'dVdt={dVdt:.4f}',
                  f'x=[{x1:.2f},{x2:.2f}]', f'dVdX=[{dVdX[0][0]:.4f},{dVdX[1][0]:.4f}]', f'f=[{f1:.4f},{f2:.4f}]', f'g=[{g1:.4f},{g2:.4f}]')
            print(f"sumV={sumV[0][0]}")

        # update
        dx = f0+g0 @ ua
        x1 = x1+dx[0][0]*t_step
        x2 = x2+dx[1][0]*t_step

        # save data
        # if i % 10 == 0:
        x1_list.append(x1)
        x2_list.append(x2)
        u1_list.append(ua[0][0])
        u2_list.append(ua[1][0])

        hat_V_list.append(hat_VV)
        dVdt_list.append(dVdt)
        dVdX1_list.append(dVdX[0][0])
        dVdX2_list.append(dVdX[1][0])
        t_list.append(i*t_step)

    return modelF, sumV, traindata, x1_list, x2_list, u1_list, u2_list, hat_V_list, t_list, FlagCLF, dVdt_list


def net_predict_dx(testdata, modelNN):

    testdata = testdata.to(torch.float32)
    X = testdata[:, 0:2]
    predict_NN = modelNN(X[:, 0:1],  X[:, 1:2])

    return predict_NN.detach()

# ----------------------------------
# prediction
# ----------------------------------
def net_predict(testdata, modelF):

    global allnum

    testdata = testdata.to(torch.float32)
    X = testdata[:, 0:2]
    X.requires_grad = True

    V_hat_ = modelF(X[:, 0:1],  X[:, 1:2]/12)
    V_hat = V_hat_ @  V_hat_.view(-1, 1) + \
        X[:, 0:1]*X[:, 0:1]*1 + X[:, 0:1] * \
        X[:, 1:2]*0 + X[:, 1:2]*X[:, 1:2]*0  # + \

    grad_VX = torch.autograd.grad(
        outputs=V_hat, inputs=X, grad_outputs=torch.ones_like(V_hat), create_graph=True)

    # if allnum == 1:
    # dVdX = grad_VX[0].view(-1, 1, 2)

    # else:
    dVdX = grad_VX[0].view(-1, 1, 2)*1

    return np.array(V_hat.detach()), dVdX.detach(), np.array(V_hat_.detach())


def net_predict_BF(testdata, modelBF):

    global allnum

    testdata = testdata.to(torch.float32)
    X = testdata[:, 0:2]
    X.requires_grad = True

    V_hat = modelBF(X[:, 0:1],  X[:, 1:2])

    V_hat = (V_hat)*10000
    grad_VX = torch.autograd.grad(
        outputs=V_hat, inputs=X, grad_outputs=torch.ones_like(V_hat), create_graph=True)
    dVdX = grad_VX[0].view(-1, 1, 2)*1

    if V_hat < 0:
        V_hat = torch.Tensor(np.array([[0]]))
        dVdX = torch.Tensor(np.array([[0], [0]]))

    else:
        V_hat = V_hat
        dVdX = dVdX.detach()

    return np.array(V_hat.detach()), dVdX.detach()
# ----------------------------------
# train
# ----------------------------------





if __name__ == '__main__':


    x1_0 = 0.2  # safe
    x2_0 = -5
    save_num = 0
    learning_rate0 = 3*1e-4
    learning_rate = learning_rate0
    loss_list = []

    FlagCLF = 0
    FlagCLF0 = 0
    kdVdt = 0
    ksumV = 0
    knonzero = 0
    allnum = 0
    flag_CLBF00 = 1

    Flag_train = 0   # Flag_train = 1 denotes training

    if Flag_train == 1:
        t_final = 10
    else:
        t_final = 10

    modelF = NetF()
    modelBF = NetBF()
    modelBF.load_state_dict(torch.load("saved_modelBF00_test35.pth"))


    modeldx = DynamicsModelRNN()
    modeldx.load_state_dict(torch.load("model_epoch_600.pth"))


    if Flag_train == 1:

        modelF = Initialize_weight(modelF)

        # modelF.load_state_dict(torch.load("saved_model_initial30.pth"))
        # modelF.load_state_dict(torch.load("saved_model_pre.pth"))
        modelF.load_state_dict(torch.load("saved_model_pre_66.pth"))
         

        traindata = systemGenerateData(
            modelF, x1_0, x2_0, Flag_train, t_final, FlagCLF0,modeldx)
        FlagCLF = traindata[9]
        print(FlagCLF)

        modelF_pre = copy.deepcopy(modelF)
        traindata_pre = traindata
        sumV_pre = traindata[1]
        sumV_pre00 = traindata[1]
        sumV_pre0 = traindata[1]
    else:
        # allnum = 1
        modelF = Initialize_weight(modelF)
        # trained model
        modelF.load_state_dict(torch.load("saved_model_pre_66.pth"))
 

    traindata = systemGenerateData(
        modelF, x1_0, x2_0, Flag_train, t_final, FlagCLF0,modeldx)  
    FlagCLF = traindata[9]

    print(f"test:i={FlagCLF};dVdt > 0")

    x1_list = traindata[3]
    x2_list = traindata[4]
    u1_list = traindata[5]
    u2_list = traindata[6]

    hat_V_list = traindata[7]
    t_list = traindata[8]
    dVdt_list = traindata[10]

    np.save(r"loss_list.npy", loss_list)
    np.save(r"t_list.npy", t_list)
    np.save(r"x1_list.npy", x1_list)
    np.save(r"x2_list.npy", x2_list)
    np.save(r"u1_list.npy", u1_list)
    np.save(r"u2_list.npy", u2_list)
    np.save(r"hat_V_list.npy", hat_V_list)
    np.save(r"dVdt_list.npy", dVdt_list)

    # define unsafe region1

    def f(x, y):
        return (x+0.22)*(x+0.22)+(y-4.6)*(y-4.6)/10000  # -0.08
    x = np.linspace(-0.26, -0.16, 800)
    y = np.linspace(2, 7, 800)
    X, Y = np.meshgrid(x, y)
    Z = f(X, Y)
    ZC = [abs(Z) < 0.0002]
    X1 = X[tuple(ZC)]
    Y1 = Y[tuple(ZC)]

    # define unsafe region2
    x3, y3 = np.mgrid[-0.26:-0.16:500j, 2:7:500j]
    z3 = (x3+0.22)*(x3+0.22)+(y3-4.6)*(y3-4.6)/10000-0.0004

    # define state set1
    x1, y1 = np.mgrid[-0.57:0.57:500j, -15:15:500j]
    z1 = 9.35*x1*x1+0.82*x1*y1+0.02*y1*y1-0.02

    # define state set2
    x2, y2 = np.mgrid[-0.57:0.57:500j, -15:15:500j]
    z2 = 9.35*x2*x2+0.82*x2*y2+0.02*y2*y2-0.2

    plt.figure(1, figsize=(4, 4))
    plt.subplot(211)
    plt.plot(t_list, x1_list, "r")
    plt.plot(t_list, x2_list, "b")
    plt.legend(labels=['x1', 'x2'])
    plt.grid()
    plt.ylabel('x1,x2')
    plt.xlabel('Time')

    plt.subplot(212)
    plt.plot(X1, Y1, "r")
    plt.contour(x3, y3, z3, levels=[-2, 0], colors='r', linestyles=['--'])
    plt.contour(x1, y1, z1, levels=[-2, 0], colors='k', linestyles=['--'])
    plt.contour(x2, y2, z2, levels=[-2, 0], colors='b', linestyles=['-'])
    plt.plot(x1_list, x2_list, "k")
    plt.grid()
    plt.xlim(-0.5, 0.5)
    plt.ylim(-15, 15)
    plt.xlabel('x1')
    plt.ylabel('x2')

    plt.figure(2, figsize=(4, 4))
    plt.subplot(311)
    plt.plot(t_list, u1_list, "r")
    plt.plot(t_list, u2_list, "b-.")
    plt.legend(labels=['u1', 'u2'])
    plt.grid()
    plt.ylabel('u1,u2')
    plt.xlabel('Time')
    plt.subplot(312)
    plt.plot(t_list, hat_V_list)
    plt.legend(labels=['hat_V'])
    plt.grid()
    plt.ylabel('hat_V')
    plt.xlabel('Time')
    plt.subplot(313)
    plt.plot(t_list, dVdt_list)
    plt.legend(labels=['dVdt'])
    plt.grid()
    plt.ylabel('dVdt')
    plt.xlabel('Time')

    plt.figure(3, figsize=(4, 4))
    plt.plot(loss_list)
    plt.grid()
    plt.ylabel('TrainLoss')
    plt.xlabel('Epochs')
    plt.show()

    input()
